
1. Place the coding in below path 
c:\xampp\htdocs\projects\fuel\web

2. Opent  localhost/phpmyadmin
   Crete DB - fuel
   
3. Import fuel.sql 

4. For Project run the path in browser


admin@gmail.com
test

user@gmail.com
test

bunk@gmail.com
test


cordova run android 
